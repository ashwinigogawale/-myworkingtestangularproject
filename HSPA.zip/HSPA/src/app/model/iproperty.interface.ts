import { IPropertyBase } from './iproprtybase';

export interface IProperty extends IPropertyBase {
    Description: string;
}
