export enum ErrorCode {
  serverDown = 0,
  unauthorised = 401
}
